/*@ logic integer f(integer n, integer m) =
    n <= 0 ? m : f(n-1, f(n-1, m+1)) + f(n-1,n-1); */

/*@ logic integer g (integer n) =
  n <= 1 ? 2 : g(n-1) * g(n-1);*/

int main(void) {
  for (int i = 0; i < 500; i++){
    /*@ assert f(10,20) > 0; */
  }

  /*@ assert \forall integer i; 1 <= i <= 500 ==> f(10,20) > 0; */

  int z = 25;
  for (int i = 0; i < 500; i++){
    /*@ assert g(z) > 0; */
  }
  /*@ assert \forall integer i; 1 <= i <= 500 ==> g(25) > 0; */
}
