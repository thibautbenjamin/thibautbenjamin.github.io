/*@ logic integer fibo(integer n) =
    n <= 0 ? 1 : n == 1 ? 1 : fibo(n-1) + fibo(n-2); */

int main(void) {
  /*@ assert fibo(2) == 2; */
  /*@ assert fibo(3) == 3; */
  /*@ assert fibo(4) == 5; */
  /*@ assert fibo(5) == 8; */
  /*@ assert fibo(6) == 13; */
  /*@ assert fibo(7) == 21; */
  /*@ assert fibo(8) == 34; */
  /*@ assert fibo(9) == 55; */
  /*@ assert fibo(10) == 89; */
  /*@ assert fibo(20) > 0; */
  /*@ assert fibo(21) > 0; */
  /*@ assert fibo(22) > 0; */
  /*@ assert fibo(23) > 0; */
  /*@ assert fibo(24) > 0; */
  /*@ assert fibo(25) > 0; */
  /*@ assert fibo(26) > 0; */
  /*@ assert fibo(27) > 0; */
  /*@ assert fibo(28) > 0; */
  /*@ assert fibo(29) > 0; */
  /*@ assert fibo(30) > 0; */
  /*@ assert fibo(31) > 0; */
  /*@ assert fibo(32) > 0; */
  /*@ assert fibo(33) > 0; */
  /*@ assert fibo(34) > 0; */
  /*@ assert fibo(35) > 0; */
  /*@ assert fibo(36) > 0; */
  /*@ assert fibo(37) > 0; */
  /*@ assert fibo(38) > 0; */
}
