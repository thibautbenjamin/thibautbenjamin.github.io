/*@ logic integer identity(integer n) =
    n <= 0 ? n : identity(n-1) + 1; */

/*@ logic integer million(integer n) =
    n <= 0 ? 0 : million(n - 1) + 1000000; */

/*@ logic integer f(integer n) =
    n <= 0 ? 0 : 5 * f(n - 1) + 10; */

int main(void) {
  /*@ assert \forall integer i; 40000 <= i <= 50000 ==> identity(i) == i; */
  /*@ assert \forall integer i; 8000 <= i <= 10000 ==> million(i) == i * 1000000; */
  /*@ assert \forall integer i; 1 <= i <= 100 ==>f (i) > 0; */
}
