#include <stddef.h>
#include <stdint.h>
#include <time.h>
#include <stdlib.h>

/*@
  predicate sorted{L}(int* a, integer low, integer high) =
    low > high ? \true :
      (\forall integer i,j; low <= i < high ==> a[i] <= a[high] ?
        sorted(a, low, high - 1) : \false);
*/

/*@
  predicate same{L}(int *a, int *b, integer low, integer high) =
    low > high ? \true :
      (a[high] == b[high] ?
        same(a,b,low,high - 1) : \false);
*/

/*@
  logic integer count{L}(int *a, int key, integer low, integer high) =
    low > high ? 0 :
      (a[high] == key ?
        count(a,key,low,high - 1) + 1: count(a,key,low,high - 1));
*/

/*@
  predicate same_elements{L}(int *a, int* b, integer low, integer high) =
    low > high ? \true :
      (count(a, a[high], low, high) == count(b, a[high], low, high) ?
        same_elements(a,b,low,high - 1): \false);
*/

void merge(int* a, size_t low, size_t middle, size_t high) {
  int tmp[high - low];
  size_t lidx = low;
  size_t hidx = middle;
  for (size_t tidx = 0; tidx < high - low; tidx++) {
    if (lidx >= middle) {
      //@ assert high_only: hidx < high;
      tmp[tidx] = a[hidx];
      hidx++;
    } else if (hidx >= high) {
      //@ assert low_only: lidx < middle;
      tmp[tidx] = a[lidx];
      lidx++;
    } else if (a[lidx] <= a[hidx]) {
      tmp[tidx] = a[lidx];
      lidx++;
    } else {
      tmp[tidx] = a[hidx];
      hidx++;
    }
  }
  for (size_t i = 0; i < high - low; i++)
    a[low + i] = tmp[i];
}

void merge_sort_aux(int* a, size_t low, size_t high) {
  if (low < high) {
    size_t middle = low + (high - low) / 2;
    if (low < middle) {
      merge_sort_aux(a,low,middle);
      L: merge_sort_aux(a,middle,high);
      merge(a,low,middle,high);
    }
  }
}

void merge_sort(int* a, size_t length) { merge_sort_aux(a,0,length); }

void copy(int* a, int* b, size_t length){
  for(int i = 0; i <= length; i++){
    b[i] = a[i];
      }
}

void fill (int* a, size_t length){
  for(int i = 0; i <= length; i++){
    a[i] = rand();
      }
}

int main(){
  srand(time(NULL));

  int* a, * b;
  size_t length = 10000;

  a = malloc ((length + 1) * sizeof(int));
  b = malloc ((length + 1) * sizeof(int));

  for (int i = 0; i <= 10000; i++){
    fill(a,length);
    copy(a,b,length);
    /*@ assert same(a,b,0,10000);*/
    merge_sort (a,length);
    /*@ assert sorted(a,0,10000);*/
    /*@ assert same_elements(a,b,0,10000); */
  }
}
