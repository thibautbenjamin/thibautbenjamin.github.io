#!/bin/bash

NCOMPIL=10
NRUN=10

COMPIL_LOG="results/compil.log"
RUN_LOG="results/run.log"
METRICS_LOG="results/metrics.log"

if [ ! -d "results" ]; then
    mkdir results
fi
if [ -d "build" ]; then
    rm build/* 2> /dev/null
else
    mkdir build
fi
if [ -f "$COMPIL_LOG" ]; then
    rm $COMPIL_LOG
fi
if [ -f "$RUN_LOG" ]; then
    rm $RUN_LOG
fi
if [ -f "$METRICS_LOG" ]; then
    rm $METRICS_LOG
fi

for SRCFILE in src/*
do
    FILENAME=${SRCFILE##*/}
    FILE=${FILENAME%.*}
    echo "benchmarking file $FILE"

    for FARG in {0..1}
    do
        BUILD="build/$FILE-$FARG"

        echo "widening strategy: $FARG"
        echo "********* $FILE - widening strategy for arguments : $FARG - widening strategy for output : $FARG *********" >> $COMPIL_LOG
        hyperfine -r $NCOMPIL "timeout 1h e-acsl-gcc.sh -c -F\"-e-acsl-widening-arguments-base $FARG -e-acsl-widening-output-base $FARG\" -o\"$BUILD.frama.c\" -O\"$BUILD.out\" src/$FILE.c" >> $COMPIL_LOG 2>&1

        echo "********* $FILE - widening strategy for arguments : $FARG - widening strategy for output : $FARG *********" >> $RUN_LOG
        hyperfine --show-output -r $NRUN "timeout 1h ./$BUILD.out.e-acsl" >> $RUN_LOG 2>&1

        echo "********* $FILE - widening strategy for arguments : $FARG - widening strategy for output : $FARG *********" >> $METRICS_LOG
        frama-c -metrics $BUILD.frama.c | grep "Function =" >> $METRICS_LOG 2>&1
    done

    BUILD="build/$FILE-GMP"

    echo "All GMP"
    echo "********* $FILE - All GMP *********" >> $COMPIL_LOG
    hyperfine -r $NCOMPIL "timeout 1h e-acsl-gcc.sh -c -g -o\"$BUILD.frama.c\" -O\"$BUILD.out\" src/$FILE.c" >> $COMPIL_LOG 2>&1

    echo "********* $FILE - All GMP *********" >> $RUN_LOG
    hyperfine --show-output -r $NRUN "timeout 1h ./$BUILD.out.e-acsl" >> $RUN_LOG 2>&1

    echo "********* $FILE - All GMP *********" >> $METRICS_LOG
    frama-c -metrics $BUILD.frama.c | grep "Function =" >> $METRICS_LOG 2>&1
done
